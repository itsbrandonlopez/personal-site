#!/usr/bin/env python3
"""Bridges Swift to DaVinci Resolve's scripting API. Bundled into the app as a
resource and invoked via Process — not run standalone. Expects
RESOLVE_SCRIPT_API/RESOLVE_SCRIPT_LIB/PYTHONPATH already set on its
environment by the caller (ResolveBridge.swift); see CLAUDE.md's Resolve
integration notes for why those live on the Swift side, not hardcoded here.

Five modes, all print exactly one line to stdout on success and exit 0;
any failure prints a message to stderr and exits 1 — no other output shape.

    resolve_bridge.py info
        -> {"timeline": "...", "startTimecode": "HH:MM:SS:FF", "frameRate": 24.0}

    resolve_bridge.py markers
        -> {"frameRate": 24.0, "markers": [{"frame": 0, "name": "..."}, ...]}

    resolve_bridge.py push-clip-markers   (reads JSON from stdin)
        stdin:  {"markers": [{"frame": 0, "name": "...", "duration": 480, "color": "Yellow"}, ...]}
        stdout: {"pushed": 1, "failed": []}

    resolve_bridge.py subtitles
        -> {"frameRate": 24.0, "cues": [{"start": 0, "end": 48, "text": "..."}, ...]}
        Reads every subtitle track's items via GetItemListInTrack("subtitle", ...).
        start/end are frame positions already re-based against Timeline.GetStartFrame()
        (TimelineItem.GetStart()/GetEnd() are in that same absolute frame domain, unlike
        GetMarkers()'s dict keys, which are already timeline-relative — see CLAUDE.md's
        Resolve integration notes). "text" is TimelineItem.GetName() — confirmed live,
        2026-08-09, against a real timeline with generated subtitles, to actually carry
        the caption text rather than a generic clip label.

    resolve_bridge.py setup-week   (reads JSON from stdin)
        stdin:  {"date": "2026.08.16"}
        stdout: {"folder": "2026.08.16", "timelines": ["...", "...", "..."], "warnings": [...]}
        Does NOT require a project's current timeline the way every mode above does —
        see `connect_project()`. Replicates the "TEMPLATE" bin's own structure
        (Footage/Timelines/Assets, or whatever it actually contains — read live, never
        hardcoded, see the docstring on `run_setup_week`) into a new "<date>" bin, both
        siblings at the root of the Media Pool (originally assumed nested under a
        "Sermons" bin — corrected 2026-08-17 once the user's real project turned out to
        keep TEMPLATE directly at the root instead), and duplicates each timeline inside
        TEMPLATE's own "Timelines" bin into the new one, substituting the date into each
        duplicate's name. Every setting (resolution, frame rate — including the vertical
        Clip 1 timeline) comes along for free via `Timeline.DuplicateTimeline`, since
        it's a real duplicate, not a freshly constructed timeline with guessed settings —
        confirmed live 2026-08-11 against this project's real "Sermons (Resolve 21)"
        project before this mode was written, per this file's own "prove the boundary"
        rule (see CLAUDE.md's Resolve integration notes). Fails loudly, does not
        overwrite, if a bin for that date already exists.
"""
import json
import os
import re
import sys


def fail(message):
    print(message, file=sys.stderr)
    sys.stderr.flush()
    # `os._exit`, not `sys.exit` — see the matching note in `main()` on the
    # success path; the interpreter-teardown crash was only ever observed on
    # a Media Pool mutation, not a failure exit, but there's no reason to
    # trust interpreter shutdown here either once it's known to be flaky.
    os._exit(1)


def connect_project():
    """The project alone — no current-timeline requirement. `setup-week`
    works at the media-pool/bin level and has no timeline of its own to
    focus; every other mode needs an actual open timeline, via `connect()`
    below."""
    try:
        import DaVinciResolveScript as dvr
    except Exception as e:
        fail(f"Could not import DaVinciResolveScript: {e!r}")

    resolve = dvr.scriptapp("Resolve")
    if resolve is None:
        fail("Resolve did not respond — is it running, and is 'External scripting "
             "using' enabled in Preferences > System > General?")

    project = resolve.GetProjectManager().GetCurrentProject()
    if project is None:
        fail("No project is open in Resolve.")

    return project


def connect():
    project = connect_project()

    timeline = project.GetCurrentTimeline()
    if timeline is None:
        fail("No timeline is open/focused in Resolve.")

    return timeline


def run_info(timeline):
    frame_rate = timeline.GetSetting("timelineFrameRate")
    try:
        frame_rate = float(frame_rate)
    except (TypeError, ValueError):
        fail(f"Could not read a numeric frame rate from Resolve (got {frame_rate!r}).")

    print(json.dumps({
        "timeline": timeline.GetName(),
        "startTimecode": timeline.GetStartTimecode(),
        "frameRate": frame_rate,
    }))


def run_markers(timeline):
    frame_rate = timeline.GetSetting("timelineFrameRate")
    try:
        frame_rate = float(frame_rate)
    except (TypeError, ValueError):
        fail(f"Could not read a numeric frame rate from Resolve (got {frame_rate!r}).")

    raw = timeline.GetMarkers() or {}
    markers = [
        {"frame": int(frame), "name": data.get("name", "")}
        for frame, data in raw.items()
    ]
    print(json.dumps({"frameRate": frame_rate, "markers": markers}))


def run_push_clip_markers(timeline):
    try:
        payload = json.loads(sys.stdin.read())
        markers = payload["markers"]
    except Exception as e:
        fail(f"Couldn't read marker data from stdin: {e!r}")

    # Purely additive — never deletes anything. This used to call
    # `DeleteMarkersByColor` first, on the theory that re-pushing one clip
    # (identified by its own stable colour, assigned in Swift by
    # `ClipMarkerColor`) should replace its own prior marker rather than
    # duplicate it. Removed 2026-08-17 at the user's explicit instruction:
    # "There shouldn't be a situation where the app removes markers." A
    # regenerated clip idea landing on the same colour as an earlier one
    # (or any other marker sharing that colour, from this app or placed by
    # hand) must never be silently deleted just because a new marker with
    # the same colour is about to be added. Re-pushing the same clip now
    # adds a second marker rather than replacing the first — a duplicate is
    # an acceptable, visible cost; a silent deletion is not.
    pushed = 0
    failed = []
    for marker in markers:
        ok = timeline.AddMarker(
            marker["frame"], marker["color"], marker["name"], "",
            max(1, marker.get("duration", 1)), "",
        )
        if ok:
            pushed += 1
        else:
            failed.append(marker.get("name", f"frame {marker.get('frame')}"))

    if pushed == 0 and markers:
        fail(f"Resolve rejected every marker (frame collision or invalid range?). Tried: {failed}")

    print(json.dumps({"pushed": pushed, "failed": failed}))


def run_subtitles(timeline):
    frame_rate = timeline.GetSetting("timelineFrameRate")
    try:
        frame_rate = float(frame_rate)
    except (TypeError, ValueError):
        fail(f"Could not read a numeric frame rate from Resolve (got {frame_rate!r}).")

    track_count = timeline.GetTrackCount("subtitle")
    if not track_count:
        fail("No subtitle track on the current timeline. Generate captions in Resolve first "
             "(Edit page > Create Subtitles from Audio).")

    # TimelineItem.GetStart()/GetEnd() are in the timeline's absolute frame
    # domain (same one Timeline.GetStartFrame() reports), not automatically
    # zero-based the way GetMarkers()'s dict keys already are — subtract it
    # explicitly rather than assume this project's timelines always start at
    # frame 0, the same "don't assume zero" discipline EDLParser applies to
    # raw EDL text.
    start_frame = timeline.GetStartFrame()
    cues = []
    for track_index in range(1, track_count + 1):
        for item in timeline.GetItemListInTrack("subtitle", track_index) or []:
            cues.append({
                "start": int(item.GetStart()) - start_frame,
                "end": int(item.GetEnd()) - start_frame,
                "text": item.GetName(),
            })

    if not cues:
        fail("The subtitle track has no cues.")

    print(json.dumps({"frameRate": frame_rate, "cues": cues}))


_DATE_PLACEHOLDER = re.compile(r"\d{4}\.XX\.XX")


def _find_child_folder(folder, name):
    for sub in folder.GetSubFolderList():
        if sub.GetName() == name:
            return sub
    return None


def run_setup_week():
    """Replicates the root-level "TEMPLATE" bin into a new "<date>" bin,
    also at the root of the Media Pool.

    Looks for "TEMPLATE" directly among the root folder's own subfolders —
    corrected 2026-08-17, per the user, from an earlier assumption that it
    lived nested one level down inside a "Sermons" bin. Reads TEMPLATE's own
    current structure live rather than hardcoding "Footage"/"Timelines"/
    "Assets" — the real project's TEMPLATE bin is the source of truth for
    what a week's folders and timelines look like, the same "don't invent,
    trust the real artifact" discipline CLAUDE.md documents for the locked
    prompt templates. Whatever subfolders TEMPLATE actually has get
    replicated (empty) into the new bin; whichever one is named "Timelines"
    additionally gets each of TEMPLATE's own timeline media-pool items
    duplicated into it via `Timeline.DuplicateTimeline` — a real duplicate,
    so resolution/frame rate (including the vertical Clip 1 timeline) come
    along automatically, never guessed at via `Timeline.SetSetting`.

    Each duplicated timeline's name has its "YYYY.XX.XX" placeholder (the
    literal pattern found in this project's real TEMPLATE timelines)
    replaced with the requested date; a template timeline with no such
    placeholder is skipped and reported back in "warnings" rather than
    silently duplicated with a stale name.
    """
    try:
        payload = json.loads(sys.stdin.read())
        date = payload["date"]
    except Exception as e:
        fail(f"Couldn't read setup data from stdin: {e!r}")

    if not re.fullmatch(r"\d{4}\.\d{2}\.\d{2}", date):
        fail(f"Expected a date like 2026.08.16, got {date!r}.")

    project = connect_project()
    mp = project.GetMediaPool()
    root = mp.GetRootFolder()

    template = _find_child_folder(root, "TEMPLATE")
    if template is None:
        fail('No "TEMPLATE" bin at the root of the Media Pool. Create one once, with '
             "the week's usual subfolders and timelines, then try again.")

    if _find_child_folder(root, date) is not None:
        fail(f'"{date}" already exists at the root of the Media Pool — delete it first '
             "or check the date.")

    week_bin = mp.AddSubFolder(root, date)
    if week_bin is None:
        fail(f"Resolve refused to create the \"{date}\" bin.")

    # One pass to build a name -> Timeline lookup, not one GetTimelineByIndex
    # scan per template timeline. Each call crosses the Fusion scripting
    # bridge, not a free Python list index — this project's project already
    # has 263 timelines and grows by ~3 every week, so the naive O(n*m) scan
    # (rescanning all of them for each of TEMPLATE's own ~3 timelines) would
    # only get slower over the life of this feature. A single pass keeps
    # this at one bridge call per existing timeline, however many there are.
    timelines_by_name = {}
    for i in range(1, project.GetTimelineCount() + 1):
        t = project.GetTimelineByIndex(i)
        timelines_by_name[t.GetName()] = t

    timelines = []
    warnings = []
    for sub in template.GetSubFolderList():
        new_sub = mp.AddSubFolder(week_bin, sub.GetName())
        if new_sub is None:
            warnings.append(f'Could not create subfolder "{sub.GetName()}".')
            continue
        if sub.GetName() != "Timelines":
            continue

        template_timelines = [c for c in sub.GetClipList() if c.GetClipProperty("Type") == "Timeline"]
        for tmpl_clip in template_timelines:
            tmpl_name = tmpl_clip.GetName()
            match = timelines_by_name.get(tmpl_name)
            if match is None:
                warnings.append(f'"{tmpl_name}" is in TEMPLATE/Timelines but Resolve has no '
                                 "matching Timeline object — skipped.")
                continue
            if not _DATE_PLACEHOLDER.search(tmpl_name):
                warnings.append(f'"{tmpl_name}" has no YYYY.XX.XX placeholder — skipped, not duplicated.')
                continue

            new_name = _DATE_PLACEHOLDER.sub(date, tmpl_name)
            project.SetCurrentTimeline(match)
            dup = match.DuplicateTimeline(new_name)
            if dup is None:
                warnings.append(f'Resolve refused to duplicate "{tmpl_name}".')
                continue
            if not mp.MoveClips([dup.GetMediaPoolItem()], new_sub):
                # `DuplicateTimeline` always lands the duplicate in the
                # *original's* own bin (TEMPLATE/Timelines), not `new_sub` —
                # if the move itself fails, leaving it there means a
                # dated, already-renamed duplicate sits permanently inside
                # TEMPLATE, the source of truth every future week's setup
                # reads from. Delete it rather than leave that behind; a
                # failed cleanup still gets its own warning, so this is
                # never silent either way.
                if not mp.DeleteTimelines([dup]):
                    warnings.append(
                        f'Duplicated "{new_name}" but could not move it into "Timelines", and '
                        'could not remove the stray duplicate from TEMPLATE either — delete '
                        f'"{new_name}" from TEMPLATE/Timelines by hand.'
                    )
                else:
                    warnings.append(f'Duplicated "{new_name}" but could not move it into "Timelines" — skipped.')
                continue
            timelines.append(dup.GetName())

    print(json.dumps({"folder": date, "timelines": timelines, "warnings": warnings}))


def main():
    modes = ("info", "markers", "push-clip-markers", "subtitles", "setup-week")
    if len(sys.argv) < 2 or sys.argv[1] not in modes:
        fail(f"Usage: resolve_bridge.py {' | '.join(modes)}")

    mode = sys.argv[1]
    if mode == "setup-week":
        run_setup_week()
    else:
        timeline = connect()
        if mode == "info":
            run_info(timeline)
        elif mode == "markers":
            run_markers(timeline)
        elif mode == "subtitles":
            run_subtitles(timeline)
        else:
            run_push_clip_markers(timeline)

    # Some Resolve scripting operations (seen so far only when mutating the
    # Media Pool, e.g. setup-week's folder/timeline creation) crash the
    # Python interpreter during its own normal shutdown/finalizer sequence —
    # confirmed live 2026-08-11: identical work, identical output, but exit
    # code 139 on plain interpreter exit versus 0 with an explicit
    # `os._exit`. Resolve itself is unaffected either way (confirmed still
    # running, project state intact) — this is purely about this short-lived
    # subprocess reporting its own already-successful work truthfully rather
    # than a spurious "process crashed" surfacing as a failure in the app.
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
